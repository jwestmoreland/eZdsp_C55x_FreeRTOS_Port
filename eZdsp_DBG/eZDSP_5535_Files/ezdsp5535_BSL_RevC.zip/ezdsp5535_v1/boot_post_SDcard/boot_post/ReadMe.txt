boot_post Test
--------------

This test can be used as a bootable test for the eZDSP. The test first tests internal memory, then the SPI Flash and then audio. Press SW1 and then SW2 to proceed to the next test. After each test the LCD screen will give out a "Done" message. If the test passed an LED will light up. For the audio test, have an audio source and output device connected to STEREO IN and STEREO OUT jacks respectively. The test willrun a loopback.