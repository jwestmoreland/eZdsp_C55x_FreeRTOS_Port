/*
*  Copyright 2004 by Texas Instruments Incorporated.
*  All rights reserved. Property of Texas Instruments Incorporated.
*  Restricted rights to use, duplicate or disclose this code are
*  granted through contract.
*  
*/
AtaError AtaSystemInit(AtaState *pAtaDrive)
{ return(vAtaSystemInit(pAtaDrive); }

