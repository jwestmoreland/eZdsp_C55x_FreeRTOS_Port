#ifndef _STD_TYPES
#define _STD_TYPES

/*
 * Just incase, if this file is included,
 * re-direct to the standard tistdtypes.h...
 */
#include "tistdtypes.h"

#endif /* _STDTYPES_H_ */

